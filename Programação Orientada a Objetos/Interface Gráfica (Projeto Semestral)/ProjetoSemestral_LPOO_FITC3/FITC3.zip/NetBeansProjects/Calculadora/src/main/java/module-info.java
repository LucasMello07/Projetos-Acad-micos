module br.edu.ifsp.sbv.calculadora {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;
    opens br.edu.ifsp.sbv.calculadora to javafx.fxml;
    exports br.edu.ifsp.sbv.calculadora;
}
