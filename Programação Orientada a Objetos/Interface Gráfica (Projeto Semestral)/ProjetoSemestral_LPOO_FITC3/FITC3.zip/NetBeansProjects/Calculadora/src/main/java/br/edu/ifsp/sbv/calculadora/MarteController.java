/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package br.edu.ifsp.sbv.calculadora;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author LENOVO
 */
public class MarteController implements Initializable {

    @FXML
    private AnchorPane fundomarte;
    
    @FXML
    private Button Voltar;
    
    
    @FXML
    public void VoltarResult() throws IOException{
       
        URL url = getClass().getResource("ResultadoController.fxml");
        Parent raiz = FXMLLoader.load(url);
        Scene cena = new Scene(raiz);
        
        Stage stage = (Stage) fundomarte.getScene().getWindow();
        stage.setScene(cena);
        stage.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
