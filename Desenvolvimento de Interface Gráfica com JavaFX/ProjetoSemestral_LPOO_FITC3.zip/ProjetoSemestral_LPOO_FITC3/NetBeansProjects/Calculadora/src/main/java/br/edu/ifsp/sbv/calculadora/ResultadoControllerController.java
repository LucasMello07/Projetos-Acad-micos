/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

package br.edu.ifsp.sbv.calculadora;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ResultadoControllerController implements Initializable {

    
    @FXML
    private AnchorPane fundo2;
    
    @FXML
    private Button voltarTelaInicial;
    
    @FXML
    private Button Mercúrio;
    
    @FXML
    private Button Vênus;
    
    @FXML
    private Button Terra;
    
    @FXML
    private Button Marte;
    
    @FXML
    private Button Júpiter;
    
    @FXML
    private Button Saturno;
    
    @FXML
    private Button Urano;
    
    @FXML
    private Button Netuno;
    
    @FXML
    private Button Fórmula;
    

    @FXML
    public void voltarTelaInicial() throws IOException{
       
        
        URL url = getClass().getResource("Calculadora.fxml");
        Parent raiz = FXMLLoader.load(url);
        Scene cena = new Scene(raiz);
        
        Stage stage = (Stage) fundo2.getScene().getWindow();
        stage.setScene(cena);
        stage.show();
    }
    
    @FXML
    public void IrMercurio() throws IOException{
       
        URL url = getClass().getResource("Mercurio.fxml");
        Parent raiz = FXMLLoader.load(url);
        Scene cena = new Scene(raiz);
        
        Stage stage = (Stage) fundo2.getScene().getWindow();
        stage.setScene(cena);
        stage.show();
    }
    
    @FXML
    public void IrVenus() throws IOException{
       
        URL url = getClass().getResource("Venus.fxml");
        Parent raiz = FXMLLoader.load(url);
        Scene cena = new Scene(raiz);
        
        Stage stage = (Stage) fundo2.getScene().getWindow();
        stage.setScene(cena);
        stage.show();
    }
    
    @FXML
    public void IrTerra() throws IOException{
       
        URL url = getClass().getResource("Terra.fxml");
        Parent raiz = FXMLLoader.load(url);
        Scene cena = new Scene(raiz);
        
        Stage stage = (Stage) fundo2.getScene().getWindow();
        stage.setScene(cena);
        stage.show();
    }
    
    @FXML
    public void IrMarte() throws IOException{
       
        URL url = getClass().getResource("Marte.fxml");
        Parent raiz = FXMLLoader.load(url);
        Scene cena = new Scene(raiz);
        
        Stage stage = (Stage) fundo2.getScene().getWindow();
        stage.setScene(cena);
        stage.show();
    }
    
    @FXML
    public void IrJúpiter() throws IOException{
       
        URL url = getClass().getResource("Júpiter.fxml");
        Parent raiz = FXMLLoader.load(url);
        Scene cena = new Scene(raiz);
        
        Stage stage = (Stage) fundo2.getScene().getWindow();
        stage.setScene(cena);
        stage.show();
    }
    
    @FXML
    public void IrSaturno() throws IOException{
       
        URL url = getClass().getResource("Saturno.fxml");
        Parent raiz = FXMLLoader.load(url);
        Scene cena = new Scene(raiz);
        
        Stage stage = (Stage) fundo2.getScene().getWindow();
        stage.setScene(cena);
        stage.show();
    }
    
    @FXML
    public void Ir_NO_URANO() throws IOException{
       
        URL url = getClass().getResource("Uranoss.fxml");
        Parent raiz = FXMLLoader.load(url);
        Scene cena = new Scene(raiz);
        
        Stage stage = (Stage) fundo2.getScene().getWindow();
        stage.setScene(cena);
        stage.show();
    }
    
    @FXML
    public void IrNetuno() throws IOException{
       
        URL url = getClass().getResource("Netuno.fxml");
        Parent raiz = FXMLLoader.load(url);
        Scene cena = new Scene(raiz);
        
        Stage stage = (Stage) fundo2.getScene().getWindow();
        stage.setScene(cena);
        stage.show();
    }
    
    
    @FXML
    public void IrFórmula() throws IOException{
       
        URL url = getClass().getResource("Formula.fxml");
        Parent raiz = FXMLLoader.load(url);
        Scene cena = new Scene(raiz);
        
        Stage stage = (Stage) fundo2.getScene().getWindow();
        stage.setScene(cena);
        stage.show();
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
