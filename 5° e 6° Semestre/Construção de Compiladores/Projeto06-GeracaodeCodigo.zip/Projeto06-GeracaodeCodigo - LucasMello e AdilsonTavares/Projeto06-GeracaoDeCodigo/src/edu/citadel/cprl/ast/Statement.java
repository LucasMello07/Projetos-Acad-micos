package edu.citadel.cprl.ast;

/**
 * Base class for all CPRL statements.
 */
public abstract class Statement extends AST {
}
