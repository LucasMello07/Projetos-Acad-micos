insert into entidade
(Registro, RazaoSocial, cnpj_cpf, site, email, cep, logradouro, numero, complemento, bairro, nome_fantasia, fkCodAtuacao, fkCodCidade)
values
('Teste', 'NaoSei', '123123', 'site.com', 'x@gmail.com', '3456-91', 'abc', '69', 'Naosei2', 'Centro', 'Feioso', 1, 568);


select entidade.RazaoSocial, colaborador.NomeContato, colaborador.DataNascimento, departamento.NomeDepartamento, cargo.NomeCargo, atuacao.NomeAtuacao
from atuacao
inner join entidade on entidade.fkCodAtuacao = atuacao.CodAtuacao
inner join colaborador on colaborador.FKCPNJ_CPF = entidade.cnpj_cpf
inner join departamento on colaborador.fkCodDepartamento = departamento.NomeDepartamento
inner join cargo on colaborador.fkCodCargo = Cargo.CodCargo
where month (DataNascimento) = 11
and NomeAtuacao = 'Escola'
order by RazaoSocial, NomeContato;


update entidade
set CodAtuacao =  3 /* O que vai */
where CodAtuacao = 2 /* Onde vai mudar */


select Classificacao.NomeClassificacao
from Classificacao 
left join PublicoConvidado on FKCodClassificacao = Classificacao.NomeClassificacao 
right join Evento on FKCodEvento = Evento.CodEvento
where Evento.CodEvento IS NULL
order by NomeClassificacao;
