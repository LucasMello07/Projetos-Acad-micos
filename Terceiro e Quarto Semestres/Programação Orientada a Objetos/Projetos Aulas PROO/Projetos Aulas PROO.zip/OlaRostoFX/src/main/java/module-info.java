module com.mycompany.olarostofx {
    requires javafx.controls;
    exports com.mycompany.olarostofx;
}
