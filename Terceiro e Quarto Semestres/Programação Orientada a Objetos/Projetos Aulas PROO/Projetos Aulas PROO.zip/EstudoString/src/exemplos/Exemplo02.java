package exemplos;

public class Exemplo02 {

    public static void main(String[] args) {
        String nome = "Ana";
        // converte para maiusculo
        System.out.println(nome.toUpperCase());
        // converte para minusculo
        System.out.println(nome.toLowerCase());
        
        System.out.println(nome);
    }
}
