package exemplos;

public class Exemplo07 {

    public static void main(String[] args) {
        char letra = '9';

        System.out.println("Digito? " +
                Character.isDigit(letra));
        
        System.out.println("Letra? " +
                Character.isLetter(letra));
        
    }
}
