package exemplo02;

public class Estados {
    public static final int PEDRA = 0;
    public static final int PAPEL = 1;
    public static final int TESOURA = 2;
}
