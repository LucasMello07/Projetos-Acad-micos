package exemplo02;

public enum Estado {
   PEDRA, PAPEL, TESOURA; 
}
