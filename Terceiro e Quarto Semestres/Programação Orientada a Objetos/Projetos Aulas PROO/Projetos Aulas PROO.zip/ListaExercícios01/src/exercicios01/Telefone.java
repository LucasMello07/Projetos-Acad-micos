package exercicios01;

public class Telefone {

    private int codigoArea;
    private int numeroLinha;
    private String tipoTelefone;

    public int getCodigoArea() {
        return codigoArea;
    }

    public int getNumeroLinha() {
        return numeroLinha;
    }

    public String getTipoTelefone() {
        return tipoTelefone;
    }

    public void setCodigoArea(int codigoArea) {
        this.codigoArea = codigoArea;
    }

    public void setNumeroLinha(int numeroLinha) {
        this.numeroLinha = numeroLinha;
    }

    public void setTipoTelefone(String tipoTelefone) {
        this.tipoTelefone = tipoTelefone;
    }
}
