/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carroUML;

/**
 *
 * @author Samuel
 */
public class Rodas {
    public int aro;
    public double pressaoCalibragem;

    public int getAro() {
        return aro;
    }

    public void setAro(int aro) {
        this.aro = aro;
    }

    public double getPressaoCalibragem() {
        return pressaoCalibragem;
    }

    public void setPressaoCalibragem(double pressaoCalibragem) {
        this.pressaoCalibragem = pressaoCalibragem;
    }
    
}
