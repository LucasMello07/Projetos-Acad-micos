/*
 * https://www.beecrowd.com.br/judge/pt/problems/view/1067
 */
package iniciante;

public class Bee1067 {
    public static void main(String [] args){
        
    }
}
