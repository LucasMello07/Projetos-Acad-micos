/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package viagemUML;

/**
 *
 * @author Samuel
 */
public class Aviao {
    
    private String distancia;
    private String partida;
    private String foto;
    private String idAviao;
    private String chegada;
    
    
    public void imprimirPercurso(){
        System.out.println("O percurso eh tal...");
    }
     public void imprimirIcone(){
       System.out.println("O icone eh tal...");
    }
}
