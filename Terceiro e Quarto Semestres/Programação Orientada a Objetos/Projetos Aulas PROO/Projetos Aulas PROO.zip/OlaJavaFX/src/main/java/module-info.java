module com.mycompany.olajavafx {
    requires javafx.controls;
    exports com.mycompany.olajavafx;
}
