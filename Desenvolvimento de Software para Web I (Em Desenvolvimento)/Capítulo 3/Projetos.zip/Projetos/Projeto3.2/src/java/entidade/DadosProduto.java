package entidade;

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "DadosProduto", urlPatterns = {"/DadosProduto"})
public class DadosProduto extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        int numero = 0;
        String titulo = request.getParameter("titulo");
        String aPrincipal = request.getParameter("aPrincipal");
        String aCoadjuvante = request.getParameter("aCoadjuvante");
        String diretor = request.getParameter("diretor");
        int anodelancamento = 0;

        Produto p = new Produto();
        p.setNumero(numero);
        p.setTitulo(titulo);
        p.setaPrincipal(aPrincipal);
        p.setaCoadjuvante(aCoadjuvante);
        p.setDiretor(diretor);
        p.setAnodelancamento(anodelancamento);

        request.setAttribute("prod", p);

        RequestDispatcher disp = request.getRequestDispatcher("exibeDados.jsp");
        disp.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "DadosProduto";
    }

}
