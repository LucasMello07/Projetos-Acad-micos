package entidade;

public class Produto {

    private int numero;
    private String titulo;
    private String aPrincipal;
    private String aCoadjuvante;
    private String diretor;
    private int anodelancamento;

    public int getNumero() {
        return numero;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getaPrincipal() {
        return aPrincipal;
    }

    public String getaCoadjuvante() {
        return aCoadjuvante;
    }

    public String getDiretor() {
        return diretor;
    }

    public int getAnodelancamento() {
        return anodelancamento;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setaPrincipal(String aPrincipal) {
        this.aPrincipal = aPrincipal;
    }

    public void setaCoadjuvante(String aCoadjuvante) {
        this.aCoadjuvante = aCoadjuvante;
    }

    public void setDiretor(String diretor) {
        this.diretor = diretor;
    }

    public void setAnodelancamento(int anodelancamento) {
        this.anodelancamento = anodelancamento;
    }
}


