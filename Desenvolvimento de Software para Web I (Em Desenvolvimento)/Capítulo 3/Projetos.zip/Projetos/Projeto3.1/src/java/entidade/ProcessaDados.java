package entidade;

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "ProcessaDados", urlPatterns = {"/dados"})
public class ProcessaDados extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        // obtém os dados do formulário
        int numero = 0;
        int cep = 0;
        String email = request.getParameter("email");
        String logradouro = request.getParameter("logradouro");
        String complemento = request.getParameter("complemento");
        String cidade = request.getParameter("cidade");
        String estado = request.getParameter("estado");
        String filhos = request.getParameter("filhos");

        // cria um novo produto e configura suas propriedades
        // usando os dados obtidos do formulário
        Produto p = new Produto();
        p.setNumero(numero);
        p.setCep(cep);
        p.setEmail(email);
        p.setLogradouro(logradouro);
        p.setComplemento(complemento);
        p.setCidade(cidade);
        p.setEstado(estado);
        p.setFilhos(filhos);

        // configura um atributo no request chamado "Prod"
        // sendo que o valor do atributo é o objeto "p"
        request.setAttribute("prod", p);

        // prepara um RequestDispatcher para direcionar para a página
        // "exibeDados.jsp" que está no mesmo diretório em relação
        // ao mapeamento deste Servlet
        RequestDispatcher disp = request.getRequestDispatcher("exibeDados.jsp");
        disp.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "ProcessaDados";
    }

}