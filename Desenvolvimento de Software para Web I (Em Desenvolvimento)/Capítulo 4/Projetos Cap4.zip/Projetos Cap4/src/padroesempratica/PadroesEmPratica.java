package padroesempratica;


public class PadroesEmPratica {

    
    public static void main(String[] args) {
      
    }
    
}
