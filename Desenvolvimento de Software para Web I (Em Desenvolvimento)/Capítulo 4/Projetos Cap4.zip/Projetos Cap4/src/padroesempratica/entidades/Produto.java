
package padroesempratica.entidades;

public class Produto {
   int id;
    String descricao;
    String quantidade;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(String cor) {
        this.quantidade = quantidade;
    }
}
