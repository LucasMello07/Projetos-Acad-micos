package padroesempratica.testes;

import java.sql.SQLException;
import padroesempratica.dao.ProdutoDAO;
import padroesempratica.entidades.Produto;

public class TesteProdutoDAO {

    public static void main(String[] args) {

        Produto produto = new Produto();
        produto.setDescricao("Sabão");
        produto.setQuantidade("Vinte");

        ProdutoDAO dao = null;

        try {

            dao = new ProdutoDAO();
            dao.salvar(produto);

        } catch (SQLException exc) {
            exc.printStackTrace();
        } finally {

            if (dao != null) {

                try {
                    dao.fecharConexao();
                } catch (SQLException exc) {
                    System.err.println("Erro ao fechar a conexão!");
                    exc.printStackTrace();
                }

            }

        }

    }
}
