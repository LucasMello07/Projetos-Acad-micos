package padroesempratica.testes;

import java.sql.SQLException;
import padroesempratica.dao.FrutaDAO;
import padroesempratica.entidades.Fruta;

public class TesteFrutaDAO {

    public static void main(String[] args) {

        Fruta fruta = new Fruta();
        fruta.setNome("Maça");
        fruta.setCor("Vermelha");

        FrutaDAO dao = null;

        try {

            dao = new FrutaDAO();
            dao.salvar(fruta);

        } catch (SQLException exc) {
            exc.printStackTrace();
        } finally {

            if (dao != null) {

                try {
                    dao.fecharConexao();
                } catch (SQLException exc) {
                    System.err.println("Erro ao fechar a conexão!");
                    exc.printStackTrace();
                }

            }

        }

    }

}
