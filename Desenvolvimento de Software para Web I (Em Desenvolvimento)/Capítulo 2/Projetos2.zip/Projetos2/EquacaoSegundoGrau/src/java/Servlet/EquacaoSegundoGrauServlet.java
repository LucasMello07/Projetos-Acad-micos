package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "EquacaoSegundoGrauServlet", urlPatterns = {"/EquacaoSegundoGrauServlet"})
public class EquacaoSegundoGrauServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        processRequest(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);

    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String A = request.getParameter("A");
        String B = request.getParameter("B");
        String C = request.getParameter("C");
        int Delta;
        int X1;
        int X2;
        int A1 = Integer.parseInt(A);
        int B1 = Integer.parseInt(B);
        int C1 = Integer.parseInt(C);

        Delta = (B1 * B1) - (4 * A1 * B1);

        X1 = -B1 + Delta / 2 * A1;
        X2 = -B1 - Delta / 2 * A1;

        System.out.println("Resultado x1" + X1);
        System.out.println("Resultado x2" + X2);

    }

}
