package formulariop.servlets;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "formulariop", urlPatterns = {"/processaDadosProduto"})
public class ProcessaDadosProduto extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        
        String codigo = request.getParameter("codigodebarras");
        String descricao = request.getParameter("descricao");
        String unidadedemedida = request.getParameter("unidadedemedida");
        String quantidadedeembalagem = request.getParameter("quantidadedeembalagem");
        String fabricante = request.getParameter("fabricante");
        
        System.out.println("Dados do Produto:");
        System.out.println("Código de Barras:" + codigo);
        System.out.println("Descrição: " + descricao);
        System.out.println("Unidade de Medida: " + unidadedemedida);
        System.out.println("Quantidade por Embalagem: " + quantidadedeembalagem);
        System.out.println("Fabricante(Nome):" + fabricante);
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "formulariop";
    }
}
