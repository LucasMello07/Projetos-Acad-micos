package calc.servlets;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "calc.servlets", urlPatterns = {"/ResultadoCalculadoraWeb"})
public class ResultadoCalculadoraWeb extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        processRequest(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);

    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String numero = request.getParameter("Primnumero");
        String numero2 = request.getParameter("Segnumero");
        String Operador = request.getParameter("Operador");
        int Primnum = Integer.parseInt(numero);
        int Segnum = Integer.parseInt(numero2);

        if (Operador.equals("A")) {
            System.out.println("O resultado: " + (Primnum + Segnum));
        } else if (Operador.equals("S")) {
            System.out.println("O resultado: " + (Primnum - Segnum));
        } else if (Operador.equals("M")) {
            System.out.println("O resultado: " + (Primnum * Segnum));
        } else {
            System.out.println("O resultado: " + (Primnum / Segnum));
        }

    }

    @Override
    public String getServletInfo() {
        return "calc.servlets";
    }
}
