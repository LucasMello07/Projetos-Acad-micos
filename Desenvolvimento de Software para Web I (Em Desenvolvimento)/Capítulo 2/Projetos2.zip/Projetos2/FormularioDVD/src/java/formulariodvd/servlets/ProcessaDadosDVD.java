package formulariodvd.servlets;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "ProcessaDadosDVD", urlPatterns = {"/processaDadosDVD"})
public class ProcessaDadosDVD extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String numero = request.getParameter("numero");
        String titulo = request.getParameter("titulo");
        String ator = request.getParameter("aPrincipal");
        String coadjuvante = request.getParameter("aCoadjuvante");
        String diretor = request.getParameter("diretor");
        String ano = request.getParameter("anodelancamento");
        
        System.out.println("Dados do DVD:");
        System.out.println("Número: " + numero);
        System.out.println("Título: " + titulo);
        System.out.println("Ator/Atriz Principal: " + ator);
        System.out.println("Ator/Atriz Coadjuvante " + coadjuvante);
        System.out.println("Diretor/Diretora:" + diretor);
        System.out.println("Ano de Lançamento: " + ano);  
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "ProcessaDadosDVD";
    }
    
}
