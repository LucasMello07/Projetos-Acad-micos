package cadastroclientes.testes;

import java.sql.SQLException;
import cadastroclientes.dao.EstadoDAO;
import cadastroclientes.entidades.Estado;

public class TesteEstadoDAO {

    public static void main(String[] args) {

        Estado estado = new Estado();
        estado.setNome("São Paulo");
        estado.setSigla("SP");

        EstadoDAO dao = null;

        try {

            dao = new EstadoDAO();
            dao.salvar(estado);

        } catch (SQLException exc) {
            exc.printStackTrace();
        } finally {

            if (dao != null) {

                try {
                    dao.fecharConexao();
                } catch (SQLException exc) {
                    System.err.println("Erro ao fechar a conexão!");
                    exc.printStackTrace();
                }

            }

        }

    }

}
