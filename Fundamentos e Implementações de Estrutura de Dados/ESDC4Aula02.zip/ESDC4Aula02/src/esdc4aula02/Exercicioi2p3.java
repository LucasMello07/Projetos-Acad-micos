/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esdc4aula02;

/**
 * Resolução do Exercício i2.3
 * 
 * @author Prof. Dr. David Buzatto
 */
public class Exercicioi2p3 {
    
    /**
     * Avalia uma expressão aritmética fornecida em qualquer forma (pré-fixada,
     * infixa ou pós-fixada), gerando o resultado. As operações de adição,
     * subtração, multiplicação e divisão devem ser suportadas.
     * 
     * @param expression Expressão a ser avaliada.
     * @return O valor obtido após o cômputo da expressão.
     * @throws IllegalArgumentException Caso a expressão fornecida seja inválida,
     * do ponto de vista estrutural, como ter um valor não numérico onde um
     * é esperado, bem como o uso de caracteres ou operações não suportadas.
     */
    public static double evaluate( String expression ) throws IllegalArgumentException {
        
        // implementação
        
        // cuidado aqui...
        return 0;
        
    }
    
}
