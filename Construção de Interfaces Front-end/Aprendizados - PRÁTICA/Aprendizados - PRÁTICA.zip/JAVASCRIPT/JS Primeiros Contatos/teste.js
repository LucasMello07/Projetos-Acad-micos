/* function myFunction(){
    document.write("teste");
} */

function Funcao(p1, p2){
    return p1 * p2;
}